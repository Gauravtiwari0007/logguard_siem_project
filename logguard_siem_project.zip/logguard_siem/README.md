# LogGuard Mini-SIEM — Python Log Analyzer & Brute-Force Detection

A beginner–intermediate cybersecurity project inspired by CEH concepts. It parses Linux OpenSSH authentication logs or normalized CSV events, detects suspicious login patterns, visualizes trends, and exports alerts.

> **Authorized use only:** Analyze logs from systems you own or have permission to investigate. The app is read-only and does not attempt logins, scan systems, or automatically block IPs/accounts.

## Features

- Parse common Linux `auth.log` / OpenSSH events:
  - failed passwords
  - invalid usernames
  - successful password/public-key logins
- Import normalized CSV events (useful for synthetic Windows events or exported SIEM records).
- Count failures by source IP and username.
- Detect repeated failures in a configurable rolling time window.
- Detect one IP targeting many distinct usernames.
- Flag a successful login that follows recent failures for the same IP and username.
- Interactive Streamlit dashboard with trend charts and top-IP summaries.
- Export normalized events and alerts to CSV/JSON.
- Unit tests for parsing and detection logic.

## Project structure

```text
logguard_siem/
├── app.py
├── logguard.py
├── requirements.txt
├── README.md
├── data/
│   ├── sample_auth.log
│   └── sample_events.csv
└── tests/
    └── test_logguard.py
```

## Requirements

- Python 3.10 or newer recommended
- pip

## Run locally

### Windows (PowerShell)

```powershell
cd logguard_siem
py -m venv .venv
.\\.venv\\Scripts\\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
streamlit run app.py
```

If PowerShell blocks activation, you can run the environment's Python directly:

```powershell
.\\.venv\\Scripts\\python.exe -m pip install -r requirements.txt
.\\.venv\\Scripts\\python.exe -m streamlit run app.py
```

### Linux / macOS

```bash
cd logguard_siem
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt
streamlit run app.py
```

Streamlit prints a local URL, usually `http://localhost:8501`. Open it in your browser. With no file uploaded, the app loads `data/sample_auth.log`.

## Try the CSV example

Upload `data/sample_events.csv` from the dashboard. The CSV must have at least:

```csv
timestamp,event,username,ip,details
2026-10-25T10:00:00,failure,alice,192.0.2.10,invalid password
2026-10-25T10:01:00,success,alice,192.0.2.10,login succeeded
```

Required columns: `timestamp`, `event`. Optional columns: `username`, `ip`, `details`.

Supported event values:
- `failure` (also accepts `failed`, `failed_login`, `login_failed`)
- `success` (also accepts `accepted`, `successful`, `login_success`)
- `invalid_user`
- `other`

For Windows Security logs, export the relevant events into this normalized schema first. This project does not yet read raw `.evtx` files directly.

## Detection logic

### 1. Repeated authentication failures
A source IP triggers an alert when the number of `failure` and `invalid_user` events reaches the configured threshold within the selected time window.

### 2. Multiple usernames targeted
A source IP triggers an alert when it fails against at least the configured number of distinct usernames in the time window. This can be a signal of username enumeration or password spraying; it is not conclusive evidence.

### 3. Failure followed by success
A successful login is flagged if one or more failures for the same username and source IP occurred within the configured window immediately before it.

## Tests

```bash
pytest -q
```

## Example expected findings

With the default settings, the bundled sample should show:
- repeated authentication failures from `198.51.100.23`
- multiple usernames targeted from the same IP
- a failure-followed-by-success alert for `alice`

The IP ranges in the samples are documentation-only ranges (RFC 5737), not real attacker addresses.

## Limitations and responsible interpretation

- Syslog records generally omit the year; the parser uses the current year. For long-term historical analysis, normalize timestamps first.
- The parser targets common OpenSSH messages; different distributions and authentication services may format logs differently.
- Source IPs can represent shared NATs, VPNs, proxies, or legitimate services.
- Thresholds are heuristic. Tune them to the environment and evaluate false positives.
- This is a learning project, not a production SIEM or a substitute for incident response procedures.
- No automated blocking is included. Any containment action should follow an approved process and human review.

## Possible extensions

- Add Windows `.evtx` parsing with `python-evtx`.
- Add severity filters, time-range filters, and alert acknowledgement.
- Store ingested events in SQLite for multi-file and historical analysis.
- Add authentication baselines and allowlists.
- Add structured logging, CI, and Docker packaging.
