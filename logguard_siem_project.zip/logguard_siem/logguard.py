from __future__ import annotations

import io
import json
import re
from typing import Iterable

import pandas as pd

# Example OpenSSH lines:
# Oct 25 10:10:01 host sshd[123]: Failed password for alice from 192.0.2.10 port 50000 ssh2
# Oct 25 10:10:02 host sshd[123]: Failed password for invalid user admin from 192.0.2.10 port 50001 ssh2
# Oct 25 10:10:03 host sshd[123]: Accepted publickey for alice from 192.0.2.10 port 50002 ssh2
MONTHS = {m: i for i, m in enumerate(
    ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"], 1
)}
SYSLOG_RE = re.compile(
    r"^(?P<month>[A-Z][a-z]{2})\s+(?P<day>\d{1,2})\s+"
    r"(?P<clock>\d{2}:\d{2}:\d{2})\s+(?P<host>\S+)\s+(?P<message>.*)$"
)
IP_RE = re.compile(r"\b(?:\d{1,3}\.){3}\d{1,3}\b")
FAILED_RE = re.compile(r"Failed password for (?:(?:invalid user)\s+)?(?P<username>\S+)\s+from\s+(?P<ip>\S+)", re.I)
INVALID_USER_RE = re.compile(r"Invalid user (?P<username>\S+) from (?P<ip>\S+)", re.I)
ACCEPTED_RE = re.compile(r"Accepted (?:password|publickey|keyboard-interactive/pam) for (?P<username>\S+) from (?P<ip>\S+)", re.I)
AUTH_FAILURE_RE = re.compile(r"authentication failure.*?user=(?P<username>\S+).*?rhost=(?P<ip>\S+)", re.I)

COLUMNS = ["timestamp", "event_type", "username", "ip", "details", "source"]


def _normalize_ip(value: str | None) -> str:
    if not value:
        return "-"
    # Keep a conservative IPv4 check for parsed OpenSSH examples.
    match = IP_RE.search(value)
    return match.group(0) if match else "-"


def parse_linux_auth_log(text: str, source_name: str = "uploaded.log") -> tuple[pd.DataFrame, list[str]]:
    """Parse common OpenSSH auth.log events. Syslog year is inferred from current year."""
    from datetime import datetime

    rows: list[dict] = []
    warnings: list[str] = []
    current_year = datetime.now().year

    for line_number, raw_line in enumerate(text.splitlines(), start=1):
        line = raw_line.strip()
        if not line:
            continue
        header = SYSLOG_RE.match(line)
        if not header:
            # Ignore unrelated lines quietly; note lines that look like SSH auth records.
            if "sshd" in line.lower() or "authentication failure" in line.lower():
                warnings.append(f"Line {line_number}: unsupported or unrecognized authentication record.")
            continue

        month = MONTHS.get(header.group("month"))
        if not month:
            warnings.append(f"Line {line_number}: unrecognized month.")
            continue
        try:
            timestamp = pd.Timestamp(
                f"{current_year}-{month:02d}-{int(header.group('day')):02d} "
                f"{header.group('clock')}"
            )
        except Exception:
            warnings.append(f"Line {line_number}: invalid timestamp.")
            continue

        message = header.group("message")
        event_type, username, ip = "other", "-", "-"
        match = FAILED_RE.search(message)
        if match:
            event_type, username, ip = "failure", match.group("username"), match.group("ip")
        else:
            match = INVALID_USER_RE.search(message)
            if match:
                event_type, username, ip = "invalid_user", match.group("username"), match.group("ip")
            else:
                match = ACCEPTED_RE.search(message)
                if match:
                    event_type, username, ip = "success", match.group("username"), match.group("ip")
                else:
                    match = AUTH_FAILURE_RE.search(message)
                    if match:
                        event_type, username, ip = "failure", match.group("username"), match.group("ip")

        rows.append({
            "timestamp": timestamp,
            "event_type": event_type,
            "username": username,
            "ip": _normalize_ip(ip),
            "details": message,
            "source": source_name,
        })

    return _events_frame(rows), warnings


def parse_csv_events(text: str, source_name: str = "uploaded.csv") -> tuple[pd.DataFrame, list[str]]:
    """Read normalized CSV events with timestamp,event,username,ip and optional details."""
    warnings: list[str] = []
    try:
        frame = pd.read_csv(io.StringIO(text))
    except Exception as exc:
        return _events_frame([]), [f"Could not read CSV: {exc}"]

    required = {"timestamp", "event"}
    if not required.issubset(set(frame.columns.str.lower())):
        return _events_frame([]), ["CSV must include at least 'timestamp' and 'event' columns."]

    frame.columns = [str(c).strip().lower() for c in frame.columns]
    for col, default in [
        ("username", "-"), ("ip", "-"), ("details", "")
    ]:
        if col not in frame.columns:
            frame[col] = default

    frame["timestamp"] = pd.to_datetime(frame["timestamp"], errors="coerce")
    bad_ts = int(frame["timestamp"].isna().sum())
    if bad_ts:
        warnings.append(f"Skipped {bad_ts} row(s) with invalid timestamps.")
        frame = frame.dropna(subset=["timestamp"])

    aliases = {
        "failed": "failure", "failed_login": "failure", "login_failed": "failure",
        "accepted": "success", "successful": "success", "login_success": "success",
        "invalid": "invalid_user", "invalid username": "invalid_user",
    }
    frame["event_type"] = frame["event"].astype(str).str.strip().str.lower().map(
        lambda x: aliases.get(x, x)
    )
    allowed = {"failure", "success", "invalid_user", "other"}
    unknown = ~frame["event_type"].isin(allowed)
    if unknown.any():
        warnings.append(f"Mapped {int(unknown.sum())} unknown event value(s) to 'other'.")
        frame.loc[unknown, "event_type"] = "other"

    frame["username"] = frame["username"].fillna("-").astype(str)
    frame["ip"] = frame["ip"].fillna("-").astype(str)
    frame["details"] = frame["details"].fillna("").astype(str)
    frame["source"] = source_name
    return _events_frame(frame[COLUMNS].to_dict("records")), warnings


def _events_frame(rows: Iterable[dict]) -> pd.DataFrame:
    frame = pd.DataFrame(list(rows), columns=COLUMNS)
    if frame.empty:
        return pd.DataFrame({
            "timestamp": pd.Series(dtype="datetime64[ns]"),
            "event_type": pd.Series(dtype="object"),
            "username": pd.Series(dtype="object"),
            "ip": pd.Series(dtype="object"),
            "details": pd.Series(dtype="object"),
            "source": pd.Series(dtype="object"),
        })
    frame["timestamp"] = pd.to_datetime(frame["timestamp"], errors="coerce")
    frame = frame.dropna(subset=["timestamp"])
    frame["event_type"] = frame["event_type"].fillna("other").astype(str)
    frame["username"] = frame["username"].fillna("-").astype(str)
    frame["ip"] = frame["ip"].fillna("-").astype(str)
    frame["details"] = frame["details"].fillna("").astype(str)
    frame["source"] = frame["source"].fillna("unknown").astype(str)
    return frame.sort_values("timestamp").reset_index(drop=True)


def load_events(text: str, source_name: str, is_csv: bool = False) -> tuple[pd.DataFrame, list[str]]:
    if is_csv:
        return parse_csv_events(text, source_name)
    return parse_linux_auth_log(text, source_name)


def analyze_events(
    events: pd.DataFrame,
    failure_threshold: int = 5,
    window_minutes: int = 10,
    distinct_users_threshold: int = 5,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Return normalized events and heuristic alerts based on rolling time windows."""
    frame = events.copy()
    if frame.empty:
        return frame, pd.DataFrame(columns=[
            "alert_type", "severity", "ip", "username", "count", "first_seen",
            "last_seen", "description", "recommendation"
        ])
    frame["timestamp"] = pd.to_datetime(frame["timestamp"], errors="coerce")
    frame = frame.dropna(subset=["timestamp"]).sort_values("timestamp").reset_index(drop=True)
    alerts: list[dict] = []
    failures = frame[frame["event_type"].isin(["failure", "invalid_user"])].copy()
    window = pd.Timedelta(minutes=int(window_minutes))

    # Sliding-window repeated failures by source IP.
    for ip, group in failures[failures["ip"].ne("-")].groupby("ip"):
        group = group.sort_values("timestamp").reset_index(drop=True)
        left = 0
        for right in range(len(group)):
            while group.loc[right, "timestamp"] - group.loc[left, "timestamp"] > window:
                left += 1
            count = right - left + 1
            if count >= failure_threshold:
                segment = group.iloc[left:right + 1]
                alerts.append({
                    "alert_type": "Repeated authentication failures",
                    "severity": "High" if count >= failure_threshold * 2 else "Medium",
                    "ip": ip,
                    "username": ", ".join(sorted(set(segment["username"].astype(str))))[:250],
                    "count": int(count),
                    "first_seen": segment["timestamp"].min(),
                    "last_seen": segment["timestamp"].max(),
                    "description": f"{count} failed/invalid authentication events from {ip} within {window_minutes} minutes.",
                    "recommendation": "Validate whether the activity is expected; review related logs and consider approved access controls.",
                })
                # One alert per IP: keep the densest window to avoid flooding.
                break

    # Distinct username failures from one IP: possible enumeration/password spray signal.
    for ip, group in failures[failures["ip"].ne("-")].groupby("ip"):
        group = group.sort_values("timestamp").reset_index(drop=True)
        left = 0
        for right in range(len(group)):
            while group.loc[right, "timestamp"] - group.loc[left, "timestamp"] > window:
                left += 1
            segment = group.iloc[left:right + 1]
            usernames = sorted(set(
                name for name in segment["username"].astype(str)
                if name and name != "-"
            ))
            if len(usernames) >= distinct_users_threshold:
                alerts.append({
                    "alert_type": "Multiple usernames targeted",
                    "severity": "Medium",
                    "ip": ip,
                    "username": ", ".join(usernames)[:250],
                    "count": len(usernames),
                    "first_seen": segment["timestamp"].min(),
                    "last_seen": segment["timestamp"].max(),
                    "description": f"{ip} generated failures for {len(usernames)} distinct usernames within {window_minutes} minutes.",
                    "recommendation": "Check for username enumeration or password spraying; confirm against known scanners and shared NATs.",
                })
                break

    # Failure followed by success for same IP + username within the configured window.
    successes = frame[frame["event_type"] == "success"]
    for _, success in successes.iterrows():
        prior = failures[
            (failures["ip"] == success["ip"])
            & (failures["username"] == success["username"])
            & (failures["timestamp"] <= success["timestamp"])
            & (failures["timestamp"] >= success["timestamp"] - window)
        ]
        if len(prior):
            alerts.append({
                "alert_type": "Failure followed by success",
                "severity": "High",
                "ip": str(success["ip"]),
                "username": str(success["username"]),
                "count": int(len(prior)),
                "first_seen": prior["timestamp"].min(),
                "last_seen": success["timestamp"],
                "description": f"{len(prior)} recent failure(s) for {success['username']} from {success['ip']} preceded a successful login.",
                "recommendation": "Verify the login with the account owner and review MFA, device, and session context.",
            })

    alert_columns = [
        "alert_type", "severity", "ip", "username", "count", "first_seen",
        "last_seen", "description", "recommendation"
    ]
    alerts_frame = pd.DataFrame(alerts, columns=alert_columns)
    if not alerts_frame.empty:
        alerts_frame = alerts_frame.drop_duplicates(
            subset=["alert_type", "ip", "username", "first_seen", "last_seen"]
        ).reset_index(drop=True)
    return frame, alerts_frame


def summarize_events(events: pd.DataFrame, alerts: pd.DataFrame) -> dict:
    return {
        "total_events": int(len(events)),
        "failed_logins": int(events["event_type"].isin(["failure", "invalid_user"]).sum()) if not events.empty else 0,
        "successful_logins": int(events["event_type"].eq("success").sum()) if not events.empty else 0,
        "alerts": int(len(alerts)),
    }


def make_alerts_csv(alerts: pd.DataFrame) -> bytes:
    return alerts.to_csv(index=False).encode("utf-8")


def make_alerts_json(alerts: pd.DataFrame) -> str:
    if alerts.empty:
        return "[]"
    safe = alerts.copy()
    for col in ("first_seen", "last_seen"):
        if col in safe:
            safe[col] = pd.to_datetime(safe[col], errors="coerce").astype(str)
    return json.dumps(safe.to_dict(orient="records"), indent=2, default=str)
