from logguard import analyze_events, load_events, parse_csv_events

SAMPLE = """Oct 25 10:00:01 labhost sshd[1]: Failed password for alice from 198.51.100.23 port 50001 ssh2
Oct 25 10:00:02 labhost sshd[2]: Failed password for invalid user admin from 198.51.100.23 port 50002 ssh2
Oct 25 10:00:03 labhost sshd[3]: Failed password for test from 198.51.100.23 port 50003 ssh2
Oct 25 10:00:04 labhost sshd[4]: Accepted password for alice from 198.51.100.23 port 50004 ssh2
"""

def test_linux_parser_extracts_events():
    events, warnings = load_events(SAMPLE, "test.log")
    assert len(events) == 4
    assert events.iloc[0]["event_type"] == "failure"
    assert events.iloc[0]["username"] == "alice"
    assert events.iloc[0]["ip"] == "198.51.100.23"
    assert events.iloc[-1]["event_type"] == "success"

def test_detects_repeated_failures_and_failure_then_success():
    events, _ = load_events(SAMPLE, "test.log")
    _, alerts = analyze_events(events, failure_threshold=3, window_minutes=10, distinct_users_threshold=3)
    types = set(alerts["alert_type"])
    assert "Repeated authentication failures" in types
    assert "Failure followed by success" in types
    assert "Multiple usernames targeted" in types

def test_csv_parser():
    csv = "timestamp,event,username,ip,details\n2026-10-25T10:00:00,failure,alice,192.0.2.2,bad password\n"
    events, warnings = parse_csv_events(csv, "test.csv")
    assert len(events) == 1
    assert events.iloc[0]["event_type"] == "failure"
